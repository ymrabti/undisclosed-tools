

    $('.watermark').watermark({
        text: 'jQueryScript.Net',
        textWidth: 100,
        gravity: 'w',
        opacity: 1,
        margin: 12
    });

    $('.watermark2').watermark({
        path: 'http://i.imgur.com/h0trtqE.jpg',
        margin: 0,
        gravity: 'nw',
        opacity: 0.5,
        outputWidth: 400
    });
